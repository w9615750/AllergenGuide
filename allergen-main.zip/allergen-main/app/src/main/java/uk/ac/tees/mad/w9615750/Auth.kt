package uk.ac.tees.mad.w9615750

import android.content.Context
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class Auth {

    private fun createUser(email: String, password: String,auth: FirebaseAuth,context: Context) {

    }
}